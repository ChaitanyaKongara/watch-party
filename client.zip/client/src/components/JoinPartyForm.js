import React, {useState} from "react";
import ReactLoading from 'react-loading';
import axios from '../axiosConfig.js';
import {useNavigate} from 'react-router-dom';

const loadingStyle = {
  position: 'inherit',
  // top: '35%',
  left: '44%',
  width: '10%',
  height: '10%',
};


function JoinPartyForm() {
  const [status, setStatus] = useState('');
  const [userName, setUserName] = useState('');
  const [roomId, setRoomId] = useState('');
  const [partyType, setPartyType] = useState('public');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  const handleJoinParty = (e) => {
    e.preventDefault();
    setStatus('loading');
    axios.post('/joinParty', {roomId: roomId, partyType: partyType, password: password})
          .then(res => {
            navigate('/party', {state: {userName: userName, partyType: partyType, password: password, roomId: roomId, userId: res.data.userId}});
          })
          .catch(err => setStatus('error'))
    console.log(userName, partyType, password, `${process.env.REACT_APP_SERVER_IP}:4000/joinParty`);
  }
  if (status === 'loading') {
    return <ReactLoading style={loadingStyle} type={"spin"} color="000"/>
  }
  return (
    <div> 
      Join Party!!
      <form onSubmit={handleJoinParty}>
        {status === 'error' && <h3>No such room</h3>}
        <label>
          Room Id:
          <input type="text" onChange={(e) => setRoomId(e.target.value)}/>
          Username:
          <input type="text" onChange={(e) => setUserName(e.target.value)}/>
          Party Type:
          <select value={partyType} onChange={(e) => setPartyType(e.target.value)}>
            <option value="public">Public Party</option>
            <option value="private">Private Party</option>
          </select>
          {partyType === 'private' && <>password: <input type="text" onChange={(e) => setPassword(e.target.value)}/></>}
        </label>
        <input type="submit" value="Join" />
      </form>
    </div>
  )
}

export default JoinPartyForm;
