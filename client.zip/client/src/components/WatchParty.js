import React,{ useEffect } from "react";
import { useLocation } from "react-router-dom";
import Chat from "./Chat.js";
import VideoPlayer from './VideoPlayer.js'

// import MemberInfo from "./MemberInfo.js";
const { io } = require("socket.io-client");

function WatchParty() {
  const location = useLocation();
  console.log(location.state)
  var socket = io(`${process.env.REACT_APP_SERVER_IP}`, {
    withCredentials: true,
  });
  // useEffect(() => {
  //   socket.on('new_message', (data) => {});
  //   socket.on('new_joinee', (data) => {});
  //   console.log(location.state);
  // }, [socket]);
  useEffect(() => {
      socket.connect()
      console.log('sending join room msg', typeof location.state);
      socket.emit('join_room', location.state);
    return (() => socket.close());
  },[]);
  if (!location.state) {
    return (<h1>Hmm</h1>)
  }
  return (
    <>
    <VideoPlayer socket={socket} data={location.state}/>
    <Chat socket={socket} data={location.state}/>
    </>
  );
}

export default WatchParty;
