import React, { useState } from "react";
import {useNavigate} from 'react-router-dom';
import ReactLoading from 'react-loading';
import axios from '../axiosConfig.js';

const loadingStyle = {
  position: 'inherit',
  // top: '35%',
  left: '44%',
  width: '10%',
  height: '10%',
};

function CreatePartyForm() {
  const [status, setStatus] = useState('');
  const [userName, setUserName] = useState('');
  const [partyType, setPartyType] = useState('public');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  const handleCreateParty = (e) => {
    e.preventDefault();
    setStatus('loading');
    axios.post('/createParty', {userName: userName, partyType: partyType, password: password})
          .then(res => {
            navigate('/party', {state: {userName: userName, partyType: partyType, password: password, roomId: res.data.roomId, userId: res.data.userId}});
          })
          .catch(err => setStatus('error'))
  }
  if (status === 'loading') {
    return <ReactLoading style={loadingStyle} type={"spin"} color="000"/>
  }
  return (
    <div> 
      Create Party!!
      <form onSubmit={handleCreateParty}>
        <label>
          UserName:
          <input type="text" onChange={(e) => setUserName(e.target.value)}/>
          Party Type:
          <select value={partyType} onChange={(e) => setPartyType(e.target.value)}>
            <option value="public">Public Room</option>
            <option value="private">Private Room</option>
          </select>
          {partyType === 'private' && <>password: <input type="text" onChange={(e) => setPassword(e.target.value)}/></>}
        </label>
        <input type="submit" value="Create" />
      </form>
    </div>
  )
}

export default CreatePartyForm;
