import React, { useState, useEffect } from "react";
import "react-chat-elements/dist/main.css";
import { MessageList, Input } from "react-chat-elements";
import ScrollToBottom from 'react-scroll-to-bottom';
import './Chat.css'

function Chat({socket, data}) {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  useEffect(() => {
    socket.on('new_message', (message_data) => {
      setMessages([...messages, {position:(message_data.userId === data.userId ? 'right' : 'left'), type:'text', title: message_data.userName, text: message_data.message}]); 
    });
  }, [socket]);
  return (
    <div >
      <ScrollToBottom className="scroll_to_bottom">
        <MessageList
          className='message-list'
          lockable={true}
          toBottomHeight={'100%'}
          dataSource={messages}
          /> 
      </ScrollToBottom>
      <div className="input-container">
        <Input
          placeholder="Type here..."
          multiline={true}
          className="text-box"
          />
        <button >Send</button>
      </div>

    </div>
  ); 
}

export default Chat;
